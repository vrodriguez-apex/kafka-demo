import signal
import sys
from kafka import KafkaProducer
import requests
import json
import time
import logging

#instType='SPOT'

# Configure logging
# A logger is an object used to log messages. 
# It provides methods to log messages at different severity levels 
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initializes a Kafka producer to send messages to a Kafka topic (okx_topic).
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Defines fetch_okx_data function to fetch data from the OKX API 
# with a retry mechanism. It retries up to 3 times with a 5-second delay 
# between attempts if an error occurs
def fetch_okx_data(retries=3, delay=5):
    url = f'https://www.okx.com/api/v5/market/tickers?instType=SPOT'
    for attempt in range(retries):
        try:
            response = requests.get(url, verify=False)  # Disable SSL verification
            response.raise_for_status()  # Raise an HTTPError for bad responses
            data = response.json()
            return data['data']
        except requests.exceptions.HTTPError as http_err:
            logger.error(f'HTTP error occurred: {http_err}')
        except requests.exceptions.RequestException as req_err:
            logger.error(f'Request error occurred: {req_err}')
        except json.JSONDecodeError as json_err:
            logger.error(f'JSON decode error occurred: {json_err}')
        
        if attempt < retries - 1:
            logger.info(f'Retrying in {delay} seconds...')
            time.sleep(delay)
    return None

# Function to clean and standardize data
def clean_data(data):
    cleaned_data = []
    for item in data:
        cleaned_item = {
            # TYPE OF INSTRUMENT
            'instType': item.get('instType', '').upper(), 
            # INSTRUMENT IDENTIFIER
            'instId': item.get('instId', '').upper(),
            # LAST TRADED PRICE OF INSTRUMENT (Most recent transaction price)
            'last': float(item.get('last', 0) or 0),
            # SIZE OF THE LAST TRADE (quantity of the last trade executed)
            'lastSz': float(item.get('lastSz', 0) or 0),
            # CURRENT ASK PRICE (lower price a seller is willing to accept for the instrument)
            'askPx': float(item.get('askPx', 0) or 0),
            # ASK SIZE (Quantity available at the current ask price)
            'askSz': float(item.get('askSz', 0) or 0),
            # CURRENT BID PRICE (highest price a buyer is willing to pay for the instrument)
            'bidPx': float(item.get('bidPx', 0) or 0),
            # CURRENT BID SIZE (Quantity available at the current bid price)
            'bidSz': float(item.get('bidSz', 0) or 0),
            # OPENING PRICE OF INSTRUMENT 24 HOURS AGO
            'open24h': float(item.get('open24h', 0) or 0),
            # HIGHEST PRICE INSTRUMENT REACH IN THE LAST 24 HOURS
            'high24h': float(item.get('high24h', 0) or 0),
            # LOWEST PRICE INSTRUMENT REACH IN THE LAST 24 HOURS
            'low24h': float(item.get('low24h', 0) or 0),
            # 24 HOUR TRADING VOLUME IN THE QUOTE CURRENCY
            'volCcy24h': float(item.get('volCcy24h', 0) or 0),
            # 24 HOUR TRADING VOLUME IN THE BASE CURRENCY
            'vol24h': float(item.get('vol24h', 0) or 0),
            # TIMESTAMP WHEN DATA WAS RECORDED
            'ts': int(item.get('ts', 0) or 0),
            # START OF DAY PRICE AT UTC0
            'sodUtc0': float(item.get('sodUtc0', 0) or 0),
            # START OF DAY PRICE AT UTC8
            'sodUtc8': float(item.get('sodUtc8', 0) or 0)
        }
        cleaned_data.append(cleaned_item)
    return cleaned_data

# Function to perform transformations on data
def transformations(data):
    for item in data:
        # This calculates the average of the current ask price and bid price. 
        # It provides a midpoint price between what sellers are asking for and what buyers are willing to pay.
        item['average_price'] = (item['askPx'] + item['bidPx']) / 2 if item['askPx'] and item['bidPx'] else 0
        # This calculates the difference between the ask price and the bid price.
        # The spread indicates the liquidity of the market; a smaller spread generally means a more liquid market.
        item['spread'] = item['askPx'] - item['bidPx'] if item['askPx'] and item['bidPx'] else 0
        # This calculates the ratio of the 24-hour trading volume in the base currency to the 24-hour trading volume in the quote currency.
        # It provides insight into the trading activity and volume dynamics between the two currencies.
        item['volume_ratio'] = item['vol24h'] / item['volCcy24h'] if item['volCcy24h'] else 0
        # This calculates the percentage change in the price of the instrument from the opening price 24 hours ago to the last traded price.
        # It shows how much the price has increased or decreased over the past 24 hours.
        item['price_change'] = ((item['last'] - item['open24h']) / item['open24h']) * 100 if item['open24h'] else 0
    return data

# Send messages to the Kafka topic with retry mechanism
def send_data(retries=3, delay=5):
    while True: #To ensure data is fetched continuously in case of failure and after max retries attempt
        data = fetch_okx_data()
        if data:
            cleaned_data = clean_data(data)
            transformed_data = transformations(cleaned_data)
            for item in transformed_data:
                success = False
                for attempt in range(retries):
                    try:
                        producer.send('okx_topic', value=item) #Send message to okx_topic
                        logger.info(f'Sent: {item}')    #Sent message that indicates item was successfully send to topic 
                        success = True #Set success flag to true
                        break  # Break the retry loop if send is successful 
                    except Exception as e:
                        logger.error(f'Error sending data to Kafka: {e}')
                        if attempt < retries - 1:
                            logger.info(f'Retrying in {delay} seconds...')
                            time.sleep(delay)
                if not success:
                    logger.error(f'Failed to send data after {retries} attempts: {item}')
        else:
            logger.info('No data fetched from OKX API.')
        time.sleep(60)  # Fetch data every 60 seconds

#Designed to handle termination signals and ensure that the script 
# shuts down orderly and in a controlled manner
#This helps prevent data loss and ensures that resources are properly released.
def signal_handler(sig, frame):
    logger.info('Shutting down gracefully...')
    producer.close()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == "__main__":
    send_data()
