import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import logging

rows_in_greed=2
columns_in_greed=2

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Function to generate data visualization from SQLite database
def generate_visualization():
    logger.info("Generating data visualization...")
    
    # Connect to the SQLite database
    conn = sqlite3.connect('Kafka_project.db')
    
    # Load data into a DataFrame
    df = pd.read_sql_query(f"""SELECT id,instType,instId,last,lastSz,askPx,askSz,
                           bidPx,bidSz,open24h,high24h,low24h,volCcy24h,vol24h,
                           ts,sodUtc0,sodUtc8,average_price,spread,volume_ratio,
                           price_change,timestamp
                            FROM market_data""", conn)
    

    # Close the database connection
    conn.close()
    
    # Convert timestamp to datetime
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    # Generate visualizations
    plt.figure(figsize=(16, 12))
    
    
    #Average Price Trend (Line Plot):
    #X-axis: Timestamp
    #Y-axis: Average Price
    #Description: This plot shows how the average price of the market data changes over time. 
    #It helps in identifying trends and patterns in price movements.
    #Plot average price trend (line plot)
    #For example, you can see if the average price is generally increasing, 
    # decreasing, or fluctuating over time.
    plt.subplot(rows_in_greed, columns_in_greed, 1)
    sns.lineplot(x='timestamp', y='average_price', data=df, color='blue')
    plt.xlabel('Timestamp')
    plt.ylabel('Average Price')
    plt.title('Average Price Trend')
    
    
    #Volume Ratio Trend (Line Plot):
    #X-axis: Timestamp
    #Y-axis: Volume Ratio
    #Description: This plot shows the trend of the volume ratio over time. 
    #It helps in analyzing the relationship between trading volume and other market factors.
    # Plot volume ratio trend (line plot)
    #You can observe how the volume ratio changes and identify any patterns or anomalies.
    #f there is a single point where the volume ratio is extremely 
    # high compared to the surrounding points, it could be an anomaly worth investigating further.
    plt.subplot(rows_in_greed, columns_in_greed, 2)
    sns.lineplot(x='timestamp', y='volume_ratio', data=df, color='red')
    plt.xlabel('Timestamp')
    plt.ylabel('Volume Ratio')
    plt.title('Volume Ratio Trend')
    
    #Price Change Trend (Scatter Plot):
    #X-axis: Timestamp
    #Y-axis: Price Change (%)
    #Description: This scatter plot illustrates the percentage change in price over time. 
    #It helps in identifying periods of significant price fluctuations.
    # Plot price change trend (scatter plot)
    #Each point represents the price change at a specific timestamp, 
    # allowing you to see how volatile the market has been.
    plt.subplot(rows_in_greed, columns_in_greed, 3)
    sns.scatterplot(x='timestamp', y='price_change', data=df, color='purple')
    plt.xlabel('Timestamp')
    plt.ylabel('Price Change (%)')
    plt.title('Price Change Trend')
    
    
    #Average Price by Instrument Id (Bar Plot):
    #X-axis: Instrument Id (Top 5)
    #Y-axis: Average Price
    #Description: This bar plot displays the average price for the top 5 instrument IDs. 
    #It helps in comparing the average prices across different instruments.
    # Bar plot: instId vs average_price
    #This can be useful for identifying which instruments have higher or lower average prices.
    plt.subplot(rows_in_greed, columns_in_greed, 4)#.figure(figsize=(10, 6))
    top_5_instId = df['instId'].value_counts().index[:5]
    sns.barplot(x='instId', y='average_price', data=df[df['instId'].isin(top_5_instId)], ci=None, palette="muted")
    plt.xlabel('Instrument Type')
    plt.ylabel('Average Price')
    plt.title('Average Price by Instrument Id (Top 5)')

    # Adjust layout and show plot
    plt.tight_layout()
    plt.show()
    
    logger.info("Data visualization generated.")

# Generate the visualization
generate_visualization()
