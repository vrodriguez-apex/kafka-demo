import signal
import sys
from kafka import KafkaConsumer
import json
import sqlite3
import time
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Delete the existing database if it exists
if os.path.exists('Kafka_project.db'):
    os.remove('Kafka_project.db')

# Function to create a Kafka consumer
def create_consumer():
    try:
        consumer = KafkaConsumer(
            'okx_topic', #The name of the Kafka topic to subscribe to
            bootstrap_servers='localhost:9092',
            auto_offset_reset='earliest', #means it will start from the beginning of the topic as current offset does not exists
            enable_auto_commit=True,
            group_id='my-group',
            value_deserializer=lambda x: json.loads(x.decode('utf-8'))
        )
        logging.info("Kafka consumer created successfully.")
        return consumer
    except Exception as e:
        logging.error(f'Error initializing Kafka consumer: {e}')
        return None

# Function to create a SQLite database connection and table
def create_db():
    try:
        conn = sqlite3.connect('Kafka_project.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS market_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                instType TEXT,
                instId TEXT,
                last REAL,
                lastSz REAL,
                askPx REAL,
                askSz REAL,
                bidPx REAL,
                bidSz REAL,
                open24h REAL,
                high24h REAL,
                low24h REAL,
                volCcy24h REAL,
                vol24h REAL,
                ts INTEGER,
                sodUtc0 REAL,
                sodUtc8 REAL,
                average_price REAL,
                spread REAL,
                volume_ratio REAL,
                price_change REAL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
        logging.info("SQLite database and table created successfully.")
        return conn
    except sqlite3.Error as e:
        logging.error(f'SQLite error: {e}')
        return None

# Function to insert data into the SQLite table
def insert_data(conn, data):
    try:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO market_data (
                instType, instId, last, lastSz, askPx, askSz, bidPx, bidSz, open24h, high24h, low24h, volCcy24h, vol24h, ts, sodUtc0, sodUtc8, average_price, spread, volume_ratio, price_change, timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ''', (
            data['instType'], data['instId'], data['last'], data['lastSz'], data['askPx'], data['askSz'], data['bidPx'], data['bidSz'],
            data['open24h'], data['high24h'], data['low24h'], data['volCcy24h'], data['vol24h'], data['ts'], data['sodUtc0'], data['sodUtc8'],
            data['average_price'], data['spread'], data['volume_ratio'], data['price_change']
        ))
        conn.commit()
        logging.info(f"Data inserted: {data}")
    except sqlite3.DatabaseError as db_err:
        logging.error(f"Database error: {db_err}")
        conn.rollback()
    except Exception as e:
        logging.error(f"Error inserting data: {e}")

#Function to consume messages 
def consume_messages(consumer, conn):
    try:
        #This loop iterates over messages received from the Kafka consumer
        #In this case is a for instead of loop as is in the producer because here
        #we are receiving what producer is fetching so we can say it would know when to stop looping
        #the producer won´t know when it would stop receiving data
        for message in consumer:
            logging.info(f'Received: {message.value}')
            insert_data(conn, message.value)
    except Exception as e:
        logging.error(f'Error occurred: {e}')
        logging.info('Closing consumer and reconnecting to Kafka...')
        consumer.close()
        time.sleep(5)  # Wait for 5 seconds before reconnecting
        consumer = create_consumer()

#Designed to handle termination signals and ensure that the script 
# shuts down orderly and in a controlled manner
#This helps prevent data loss and ensures that resources are properly released.
def signal_handler(sig, frame):
    logging.info('Shutting down gracefully...')
    if consumer:
        consumer.close()
    if conn:
        conn.close()
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == "__main__":
    consumer = create_consumer()
    conn = create_db()

    if consumer and conn:
        consume_messages(consumer, conn)
    else:
        logging.error('Failed to create Kafka consumer or database connection.')
