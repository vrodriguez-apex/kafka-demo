import subprocess
import threading
import time
import logging


producer="kafka-project\producer.py"
consumer="kafka-project\consumer.py"

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Function to start the producer script
def start_producer():
    logger.info("Starting producer...")
    subprocess.run(["python", producer])
    logger.info("Producer finished.")

# Function to start the consumer script
def start_consumer():
    logger.info("Starting consumer...")
    subprocess.run(["python", consumer])
    logger.info("Consumer finished.")

if __name__ == "__main__":
    # Start producer and consumer in separate threads without affecting each other
    producer_thread = threading.Thread(target=start_producer)
    consumer_thread = threading.Thread(target=start_consumer)
    
    producer_thread.start()
    consumer_thread.start()
    
    # Run producer and consumer for a specific duration (e.g., 5 minutes)
    time.sleep(300)  # 300 seconds = 5 minutes
    
    # Wait for threads to complete to allow the program 
    # continue running until both threads completes their execution
    producer_thread.join()
    consumer_thread.join()
    
    logger.info("Producer and consumer have finished execution.")
